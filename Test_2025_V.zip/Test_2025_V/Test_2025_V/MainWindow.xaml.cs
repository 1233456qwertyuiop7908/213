﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test_2025_V
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }
        string passishe = "";
        private void auth_Click(object sender, RoutedEventArgs e)
        {
            if (Checknull(passishe, loginBox.Text))
            {
                CheckLengthPass(passishe);
                CheckMailAndPhone(loginBox.Text);
            }

        }

        private bool Checknull(string pass, string email)
        {
            bool isNull = true;
            if (!string.IsNullOrEmpty(pass) || !string.IsNullOrEmpty(email)) 
            {
            isNull = false;
            }
            return isNull;
        }
        private void CheckLengthPass(string pas)
        {
            if (pas.Length < 8)
            {
                MessageBox.Show("Длина пароля меньше 8 символов!");
                return;
            }
        }
        private void CheckMailAndPhone(string log)
        { 
            string pattern = "";
            if (Checkradio())
            {
                pattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                if (!Regex.IsMatch(log, pattern, RegexOptions.IgnoreCase)) 
                {

                    MessageBox.Show("Почта не существует!");
                    return;

                }
                
            }
            else
            {
                pattern = "^\\+(\\d{1,3})\\s?\\((\\d{3})\\)\\s?\\d{3}-\\d{4}$";
                if (!Regex.IsMatch(log, pattern, RegexOptions.IgnoreCase))
                {

                    MessageBox.Show("Телефон не верный!");
                    return;

                }
            }
        }
        
        private bool Checkradio()
        {
            bool statusradioMail = true;
            if (mail.IsChecked != false)
            {
                statusradioMail = true;

            }
            else
            {
                statusradioMail = false;
            }
            return statusradioMail;
        }

        private void passHide_Click(object sender, RoutedEventArgs e)
        {

        }
        
        private void passHide_Checked(object sender, RoutedEventArgs e)
        {
            if (passHide.IsChecked == true)
            {
                passishe = TextpassBox.Text;
                passBox.Visibility = Visibility.Visible;
                passBox.Password = passishe;
                TextpassBox.Visibility = Visibility.Collapsed;
                
            }
            else
            {
                
                TextpassBox.Visibility=Visibility.Visible;
                passishe = passBox.Password;
                passBox.Visibility = Visibility.Collapsed;
                TextpassBox.Text = passishe;
            }
            
        }
    }
}
